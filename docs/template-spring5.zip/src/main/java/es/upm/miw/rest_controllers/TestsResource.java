package es.upm.miw.rest_controllers;

import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping(TestsResource.TESTS)
public class TestsResource {

    public static final String TESTS = "/tests";

    @GetMapping
    public String read() {
        return "OK!!!";
    }

}
